import React, { useState } from 'react';
import { usePins } from '../../contexts/PinContext';
import { X, Plus, Calendar, Tag, Filter, ChevronDown, ChevronUp } from 'lucide-react';
import { format } from 'date-fns';

const FilterBar: React.FC = () => {
  const { 
    filters, 
    addHashtagFilter, 
    removeHashtagFilter,
    setDateRangeFilter, 
    clearAllFilters 
  } = usePins();
  
  const [hashtagInput, setHashtagInput] = useState('');
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  const handleHashtagSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (hashtagInput.trim()) {
      addHashtagFilter(hashtagInput.trim());
      setHashtagInput('');
    }
  };

  const handleDateChange = (start: string | undefined, end: string | undefined) => {
    setStartDate(start || '');
    setEndDate(end || '');
    setDateRangeFilter(start, end);
  };

  const handleClearFilters = () => {
    clearAllFilters();
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-4 animate-fade-in">
      <div className="flex flex-col space-y-4">
        {/* Active filters display */}
        {(filters.hashtags.length > 0 || filters.dateRange.start || filters.dateRange.end) && (
          <div className="flex flex-wrap items-center gap-2 pb-3 border-b border-gray-200">
            <span className="text-sm font-medium text-gray-700 flex items-center">
              <Filter size={16} className="mr-1" /> Active filters:
            </span>
            
            {filters.hashtags.map((tag) => (
              <span 
                key={tag} 
                className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 text-primary-800"
              >
                #{tag}
                <button 
                  onClick={() => removeHashtagFilter(tag)}
                  className="ml-1 rounded-full hover:bg-primary-200 p-0.5"
                >
                  <X size={14} />
                </button>
              </span>
            ))}
            
            {(filters.dateRange.start || filters.dateRange.end) && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-secondary-100 text-secondary-800">
                <Calendar size={14} className="mr-1" />
                {filters.dateRange.start 
                  ? format(new Date(filters.dateRange.start), 'MMM d, yyyy') 
                  : 'Any'} 
                {' - '}
                {filters.dateRange.end 
                  ? format(new Date(filters.dateRange.end), 'MMM d, yyyy')
                  : 'Any'}
                <button 
                  onClick={() => handleDateChange(undefined, undefined)}
                  className="ml-1 rounded-full hover:bg-secondary-200 p-0.5"
                >
                  <X size={14} />
                </button>
              </span>
            )}
            
            {(filters.hashtags.length > 0 || filters.dateRange.start || filters.dateRange.end) && (
              <button 
                onClick={handleClearFilters}
                className="text-sm text-gray-600 hover:text-gray-900 underline"
              >
                Clear all
              </button>
            )}
          </div>
        )}
        
        {/* Hashtag filter input */}
        <div>
          <div className="flex items-center">
            <Tag size={16} className="text-gray-500 mr-2" />
            <h3 className="text-sm font-medium text-gray-700">Filter by Hashtag</h3>
          </div>
          <form onSubmit={handleHashtagSubmit} className="mt-1 flex">
            <div className="relative flex-1">
              <input
                type="text"
                value={hashtagInput}
                onChange={(e) => setHashtagInput(e.target.value)}
                placeholder="Type hashtags (e.g. beach)"
                className="w-full px-4 py-2 border border-gray-300 rounded-l-lg focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-r-lg bg-primary-600 hover:bg-primary-700 text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors"
            >
              <Plus size={18} />
            </button>
          </form>
        </div>
        
        {/* Date filter toggle */}
        <div>
          <button
            onClick={() => setShowDateFilter(!showDateFilter)}
            className="w-full flex items-center justify-between px-4 py-2 text-left border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors"
          >
            <div className="flex items-center">
              <Calendar size={16} className="text-gray-500 mr-2" />
              <span className="text-sm font-medium text-gray-700">Filter by Date</span>
            </div>
            {showDateFilter ? (
              <ChevronUp size={16} className="text-gray-500" />
            ) : (
              <ChevronDown size={16} className="text-gray-500" />
            )}
          </button>
          
          {showDateFilter && (
            <div className="mt-2 p-4 bg-white border border-gray-200 rounded-lg shadow-lg animate-slide-up">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="start-date" className="block text-sm font-medium text-gray-700 mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    id="start-date"
                    value={startDate}
                    onChange={(e) => handleDateChange(e.target.value || undefined, endDate || undefined)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
                <div>
                  <label htmlFor="end-date" className="block text-sm font-medium text-gray-700 mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    id="end-date"
                    value={endDate}
                    onChange={(e) => handleDateChange(startDate || undefined, e.target.value || undefined)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FilterBar;