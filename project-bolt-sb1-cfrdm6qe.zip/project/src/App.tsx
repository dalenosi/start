import React, { useState, useRef } from 'react';
import { PinProvider } from './contexts/PinContext';
import MapView from './components/Map/MapView';
import FilterBar from './components/Filters/FilterBar';
import PinsList from './components/PinsList/PinsList';
import PinForm from './components/Forms/PinForm';
import AdminLogin from './pages/AdminLogin';
import { Pin } from './types';
import { Plus } from 'lucide-react';

function App() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingPin, setEditingPin] = useState<Pin | undefined>(undefined);
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number } | undefined>(undefined);
  const [showList, setShowList] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [mapCenter, setMapCenter] = useState<{ latitude: number; longitude: number } | null>(null);
  const dragRef = useRef<{ startY: number; currentY: number } | null>(null);
  const [sortedPins, setSortedPins] = useState<Array<{ pin: Pin; distance: number }>>([]);

  const handleAddPin = () => {
    setEditingPin(undefined);
    setSelectedLocation(undefined);
    setShowAddForm(true);
  };

  const handleEditPin = (pin: Pin) => {
    setEditingPin(pin);
    setSelectedLocation(undefined);
    setShowAddForm(true);
  };

  const handleLocationSelected = (lat: number, lng: number) => {
    setSelectedLocation({ lat, lng });
  };

  const handleNavigateToPin = (lat: number, lng: number) => {
    setMapCenter({ latitude: lat, longitude: lng });
    setShowList(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    dragRef.current = {
      startY: e.touches[0].clientY,
      currentY: e.touches[0].clientY
    };
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!dragRef.current) return;
    dragRef.current.currentY = e.touches[0].clientY;
    const deltaY = dragRef.current.startY - dragRef.current.currentY;
    if (deltaY > 50 && !showList) {
      setShowList(true);
    } else if (deltaY < -50 && showList) {
      setShowList(false);
    }
  };

  const handleTouchEnd = () => {
    dragRef.current = null;
  };

  const handleLongPress = () => {
    setShowLogin(true);
  };

  const handlePinsSort = (sorted: Array<{ pin: Pin; distance: number }>) => {
    setSortedPins(sorted);
  };

  if (showLogin) {
    return (
      <PinProvider>
        <AdminLogin onLogin={() => setShowLogin(false)} />
      </PinProvider>
    );
  }

  return (
    <PinProvider>
      <div 
        className="min-h-screen bg-gray-100"
        onTouchStart={(e) => {
          const touch = e.touches[0];
          let timer = setTimeout(() => handleLongPress(), 10000);
          const cleanup = () => {
            clearTimeout(timer);
            document.removeEventListener('touchend', cleanup);
            document.removeEventListener('touchmove', cleanup);
          };
          document.addEventListener('touchend', cleanup);
          document.addEventListener('touchmove', cleanup);
        }}
      >
        <div className="fixed inset-0 z-0">
          <MapView 
            onLocationSelected={handleLocationSelected}
            selectionMode={showAddForm && !editingPin}
            height="h-full"
            center={mapCenter}
            onPinsSort={handlePinsSort}
          />
        </div>

        <div className="relative z-10">
          {!showAddForm && !showList && (
            <div className="px-4 py-4">
              <FilterBar />
            </div>
          )}

          <div 
            className={`fixed inset-x-0 bottom-0 bg-white rounded-t-2xl shadow-lg transition-transform duration-300 ease-in-out transform ${
              showList ? 'translate-y-0' : 'translate-y-[calc(100%-40px)]'
            } ${showAddForm ? 'z-20' : 'z-30'}`}
            style={{ height: 'calc(75vh)' }}
          >
            <div 
              className="flex justify-center py-2 cursor-grab"
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
            >
              <div className="w-12 h-1 bg-gray-300 rounded-full" />
            </div>
            <div className="h-[calc(75vh-32px)] overflow-y-auto">
              <PinsList 
                onNavigateToPin={handleNavigateToPin}
                onEditPin={handleEditPin}
                sortedPins={sortedPins}
              />
            </div>
          </div>
        </div>
        
        {showAddForm && (
          <div className="fixed inset-x-0 bottom-0 bg-white shadow-lg rounded-t-xl z-40" style={{ height: '60vh' }}>
            <div className="h-full overflow-y-auto">
              <PinForm
                initialPin={editingPin}
                onSubmit={(pinData) => {
                  setShowAddForm(false);
                }}
                onCancel={() => setShowAddForm(false)}
                selectedLocation={selectedLocation}
              />
            </div>
          </div>
        )}
        
        <div className={`fixed bottom-6 right-6 ${showAddForm || showList ? 'z-10' : 'z-50'}`}>
          <button
            onClick={handleAddPin}
            className="w-14 h-14 flex items-center justify-center rounded-full bg-primary-600 text-white shadow-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors"
            aria-label="Add new pin"
          >
            <Plus size={24} />
          </button>
        </div>
      </div>
    </PinProvider>
  );
}

export default App;