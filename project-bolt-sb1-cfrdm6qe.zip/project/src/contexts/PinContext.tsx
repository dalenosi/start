import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Pin, Filters } from '../types';
import initialPins from '../data/initialPins';
import { isBefore, isAfter, parseISO } from 'date-fns';

interface PinContextProps {
  pins: Pin[];
  filteredPins: Pin[];
  filters: Filters;
  isAdmin: boolean;
  setIsAdmin: (value: boolean) => void;
  addPin: (pin: Omit<Pin, 'id' | 'createdAt'>) => void;
  updatePin: (pin: Pin) => void;
  deletePin: (id: string) => void;
  addHashtagFilter: (hashtag: string) => void;
  removeHashtagFilter: (hashtag: string) => void;
  clearHashtagFilters: () => void;
  setDateRangeFilter: (start?: string, end?: string) => void;
  clearDateRangeFilter: () => void;
  clearAllFilters: () => void;
}

const PinContext = createContext<PinContextProps | undefined>(undefined);

export const PinProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [pins, setPins] = useState<Pin[]>(() => {
    const savedPins = localStorage.getItem('pins');
    return savedPins ? JSON.parse(savedPins) : initialPins;
  });
  
  const [isAdmin, setIsAdmin] = useState(() => localStorage.getItem('isAdmin') === 'true');
  
  const [filters, setFilters] = useState<Filters>({
    hashtags: [],
    dateRange: {
      start: undefined,
      end: undefined,
    },
  });

  useEffect(() => {
    localStorage.setItem('pins', JSON.stringify(pins));
  }, [pins]);

  const filteredPins = pins.filter((pin) => {
    if (filters.hashtags.length > 0) {
      const hasMatchingHashtag = pin.hashtags.some((hashtag) =>
        filters.hashtags.includes(hashtag)
      );
      if (!hasMatchingHashtag) return false;
    }

    if (filters.dateRange.start || filters.dateRange.end) {
      const pinDate = parseISO(pin.createdAt);
      
      if (filters.dateRange.start) {
        const startDate = parseISO(filters.dateRange.start);
        if (isBefore(pinDate, startDate)) return false;
      }
      
      if (filters.dateRange.end) {
        const endDate = parseISO(filters.dateRange.end);
        if (isAfter(pinDate, endDate)) return false;
      }
    }

    return true;
  });

  const addPin = (newPin: Omit<Pin, 'id' | 'createdAt'>) => {
    const pin: Pin = {
      ...newPin,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setPins((prevPins) => {
      const updatedPins = [...prevPins, pin];
      localStorage.setItem('pins', JSON.stringify(updatedPins));
      return updatedPins;
    });
  };

  const updatePin = (updatedPin: Pin) => {
    setPins((prevPins) => {
      const updatedPins = prevPins.map((pin) => (pin.id === updatedPin.id ? updatedPin : pin));
      localStorage.setItem('pins', JSON.stringify(updatedPins));
      return updatedPins;
    });
  };

  const deletePin = (id: string) => {
    if (!isAdmin) {
      console.error('Unauthorized deletion attempt');
      return;
    }
    setPins((prevPins) => {
      const updatedPins = prevPins.filter((pin) => pin.id !== id);
      localStorage.setItem('pins', JSON.stringify(updatedPins));
      return updatedPins;
    });
  };

  const addHashtagFilter = (hashtag: string) => {
    if (!filters.hashtags.includes(hashtag)) {
      setFilters((prevFilters) => ({
        ...prevFilters,
        hashtags: [...prevFilters.hashtags, hashtag],
      }));
    }
  };

  const removeHashtagFilter = (hashtag: string) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      hashtags: prevFilters.hashtags.filter((h) => h !== hashtag),
    }));
  };

  const clearHashtagFilters = () => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      hashtags: [],
    }));
  };

  const setDateRangeFilter = (start?: string, end?: string) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      dateRange: { start, end },
    }));
  };

  const clearDateRangeFilter = () => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      dateRange: { start: undefined, end: undefined },
    }));
  };

  const clearAllFilters = () => {
    setFilters({
      hashtags: [],
      dateRange: { start: undefined, end: undefined },
    });
  };

  return (
    <PinContext.Provider
      value={{
        pins,
        filteredPins,
        filters,
        isAdmin,
        setIsAdmin,
        addPin,
        updatePin,
        deletePin,
        addHashtagFilter,
        removeHashtagFilter,
        clearHashtagFilters,
        setDateRangeFilter,
        clearDateRangeFilter,
        clearAllFilters,
      }}
    >
      {children}
    </PinContext.Provider>
  );
};

export const usePins = () => {
  const context = useContext(PinContext);
  if (context === undefined) {
    throw new Error('usePins must be used within a PinProvider');
  }
  return context;
};