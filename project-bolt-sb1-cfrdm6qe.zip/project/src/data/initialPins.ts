import { Pin } from '../types';

const initialPins: Pin[] = [
  {
    id: '1',
    title: 'Athens',
    hashtags: ['ancient', 'history'],
    description: 'The capital and largest city of Greece, known for its ancient history and monuments.',
    imageUrl: 'https://images.pexels.com/photos/951539/pexels-photo-951539.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    latitude: 37.9838,
    longitude: 23.7275,
    createdAt: '2023-05-10T10:00:00Z',
  },
  {
    id: '2',
    title: 'Berlin',
    hashtags: ['culture', 'modern'],
    description: 'The capital and largest city of Germany, known for its cultural history and modern architecture.',
    imageUrl: 'https://images.pexels.com/photos/2570063/pexels-photo-2570063.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    websiteUrl: 'https://www.berlin.de/en/',
    latitude: 52.5200,
    longitude: 13.4050,
    createdAt: '2023-06-15T14:30:00Z',
  },
  {
    id: '3',
    title: 'Madrid',
    hashtags: ['culture', 'food'],
    description: 'The capital and largest city of Spain, famous for its rich culture and delicious food.',
    imageUrl: 'https://images.pexels.com/photos/3254729/pexels-photo-3254729.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    latitude: 40.4168,
    longitude: -3.7038,
    createdAt: '2023-07-20T09:15:00Z',
  },
  {
    id: '4',
    title: 'Paris',
    hashtags: ['city', 'romance'],
    description: 'The capital of France, known as the "City of Light" and one of the most romantic destinations in the world.',
    imageUrl: 'https://images.pexels.com/photos/699466/pexels-photo-699466.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    websiteUrl: 'https://en.parisinfo.com/',
    latitude: 48.8566,
    longitude: 2.3522,
    createdAt: '2023-08-05T16:45:00Z',
  },
  {
    id: '5',
    title: 'Rome',
    hashtags: ['history', 'architecture'],
    description: 'The capital of Italy, known for its rich history, architecture, and ancient Roman ruins.',
    imageUrl: 'https://images.pexels.com/photos/532263/pexels-photo-532263.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    websiteUrl: 'https://www.turismoroma.it/en',
    latitude: 41.9028,
    longitude: 12.4964,
    createdAt: '2023-09-12T11:20:00Z',
  },
  {
    id: '6',
    title: 'Stockholm',
    hashtags: ['nordic', 'design'],
    description: 'The capital of Sweden, known for its beautiful archipelago, Nordic culture, and design aesthetics.',
    imageUrl: 'https://images.pexels.com/photos/4215113/pexels-photo-4215113.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    latitude: 59.3293,
    longitude: 18.0686,
    createdAt: '2023-10-25T13:10:00Z',
  }
];

export default initialPins;