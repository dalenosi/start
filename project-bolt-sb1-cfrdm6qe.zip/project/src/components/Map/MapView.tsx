import React, { useState, useRef, useCallback } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, useMap } from 'react-leaflet';
import { LatLngExpression, Icon, LatLng } from 'leaflet';
import { MapPin, ExternalLink, Trash2 } from 'lucide-react';
import { usePins } from '../../contexts/PinContext';
import { format } from 'date-fns';

interface LocationMarkerProps {
  onLocationSelected: (lat: number, lng: number) => void;
  selectionMode: boolean;
}

const customIcon = new Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const activeIcon = new Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

interface CenterMapProps {
  center: { latitude: number; longitude: number } | null;
  onCenterChanged: (center: LatLng) => void;
}

const CenterMap: React.FC<CenterMapProps> = ({ center, onCenterChanged }) => {
  const map = useMap();
  
  React.useEffect(() => {
    if (center) {
      map.setView([center.latitude, center.longitude], 13);
    }
  }, [center, map]);

  useMapEvents({
    moveend: () => {
      onCenterChanged(map.getCenter());
    },
  });

  return null;
};

const LocationMarker: React.FC<LocationMarkerProps> = ({ onLocationSelected, selectionMode }) => {
  const [position, setPosition] = useState<LatLngExpression | null>(null);
  
  const map = useMapEvents({
    click(e) {
      if (selectionMode) {
        setPosition(e.latlng);
        onLocationSelected(e.latlng.lat, e.latlng.lng);
      }
    },
  });

  return position === null ? null : (
    <Marker position={position} icon={activeIcon}>
      <Popup>You selected this location</Popup>
    </Marker>
  );
};

interface MapViewProps {
  onLocationSelected?: (lat: number, lng: number) => void;
  selectionMode?: boolean;
  height?: string;
  center?: { latitude: number; longitude: number } | null;
  onPinsSort?: (sortedPins: Array<{ pin: any; distance: number }>) => void;
}

const MapView: React.FC<MapViewProps> = ({ 
  onLocationSelected = () => {}, 
  selectionMode = false,
  height = 'h-[calc(100vh-8rem)]',
  center = null,
  onPinsSort = () => {}
}) => {
  const { filteredPins, addHashtagFilter, deletePin, isAdmin } = usePins();
  const defaultCenter: LatLngExpression = [48.8566, 2.3522];

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const handleCenterChanged = useCallback((center: LatLng) => {
    const pinsWithDistance = filteredPins.map(pin => ({
      pin,
      distance: calculateDistance(
        center.lat,
        center.lng,
        pin.latitude,
        pin.longitude
      )
    }));

    pinsWithDistance.sort((a, b) => a.distance - b.distance);
    onPinsSort(pinsWithDistance);
  }, [filteredPins, onPinsSort]);

  const shouldOpenInSameTab = (url: string) => {
    return url.includes('https://goldenrod-oyster-704807.hostingersite.com/');
  };
  
  return (
    <div className={`w-full ${height} rounded-lg overflow-hidden shadow-md`}>
      <MapContainer
        center={defaultCenter}
        zoom={5}
        scrollWheelZoom={true}
        style={{ height: '100%', width: '100%' }}
      >
        <CenterMap center={center} onCenterChanged={handleCenterChanged} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {filteredPins.map((pin) => (
          <Marker 
            key={pin.id} 
            position={[pin.latitude, pin.longitude]} 
            icon={customIcon}
          >
            <Popup className="rounded-lg overflow-hidden">
              <div className="w-64">
                {pin.imageUrl && (
                  <div className="w-full h-32 overflow-hidden rounded-t-lg mb-2">
                    <img 
                      src={pin.imageUrl} 
                      alt={pin.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className="p-2">
                  <div className="flex justify-between items-start">
                    <h3 className="text-lg font-semibold mb-1">{pin.title}</h3>
                    {isAdmin && (
                      <button
                        onClick={() => deletePin(pin.id)}
                        className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full transition-colors"
                        title="Delete pin"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">
                    {format(new Date(pin.createdAt), 'MMM d, yyyy')}
                  </p>
                  <p className="text-sm mb-2">{pin.description}</p>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {pin.hashtags.map((tag) => (
                      <button
                        key={tag}
                        onClick={() => addHashtagFilter(tag)}
                        className="px-2 py-1 bg-primary-100 text-primary-700 rounded-full text-xs hover:bg-primary-200 transition-colors"
                      >
                        #{tag}
                      </button>
                    ))}
                  </div>
                  {pin.websiteUrl && (
                    <a
                      href={pin.websiteUrl}
                      target={shouldOpenInSameTab(pin.websiteUrl) ? '_self' : '_blank'}
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-secondary-600 hover:text-secondary-800 text-sm"
                    >
                      Visit website <ExternalLink size={14} className="ml-1" />
                    </a>
                  )}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
        
        {selectionMode && (
          <LocationMarker onLocationSelected={onLocationSelected} selectionMode={selectionMode} />
        )}
      </MapContainer>
      
      {selectionMode && (
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white px-4 py-2 rounded-full shadow-lg z-[1000] text-sm flex items-center">
          <MapPin size={16} className="mr-2 text-primary-600" />
          Click on the map to set location
        </div>
      )}
    </div>
  );
};

export default MapView;