export interface Pin {
  id: string;
  title: string;
  hashtags: string[];
  description: string;
  imageUrl: string;
  websiteUrl?: string;
  latitude: number;
  longitude: number;
  createdAt: string;
  startDate?: string;
  endDate?: string;
}

export interface Filters {
  hashtags: string[];
  dateRange: {
    start?: string;
    end?: string;
  };
}