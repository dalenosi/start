import React from 'react';
import { format } from 'date-fns';
import { Pin } from '../../types';
import { usePins } from '../../contexts/PinContext';
import { MapPin, ExternalLink, Edit, Trash2 } from 'lucide-react';

interface PinCardProps {
  pin: Pin;
  distance: number;
  onEdit: (pin: Pin) => void;
  onDelete: (id: string) => void;
  onNavigateToPin: (lat: number, lng: number) => void;
}

const PinCard: React.FC<PinCardProps> = ({ pin, distance, onEdit, onDelete, onNavigateToPin }) => {
  const { addHashtagFilter, isAdmin } = usePins();

  const shouldOpenInSameTab = (url: string) => {
    return url.includes('https://goldenrod-oyster-704807.hostingersite.com/');
  };

  const formatDistance = (distance: number) => {
    if (distance < 1) {
      return `${Math.round(distance * 1000)}m`;
    }
    return `${Math.round(distance)}km`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg animate-scale-in">
      {pin.imageUrl && (
        <div className="relative h-40 overflow-hidden">
          <img 
            src={pin.imageUrl} 
            alt={pin.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute top-0 right-0 p-2 flex space-x-1">
            <button
              onClick={() => onNavigateToPin(pin.latitude, pin.longitude)}
              className="bg-white bg-opacity-80 p-1.5 rounded-full text-primary-600 hover:bg-opacity-100 transition-colors"
              title="Navigate to location"
            >
              <MapPin size={16} />
            </button>
            {pin.websiteUrl && (
              <a
                href={pin.websiteUrl}
                target={shouldOpenInSameTab(pin.websiteUrl) ? '_self' : '_blank'}
                rel="noopener noreferrer"
                className="bg-white bg-opacity-80 p-1.5 rounded-full text-secondary-600 hover:bg-opacity-100 transition-colors"
                title="Visit website"
              >
                <ExternalLink size={16} />
              </a>
            )}
          </div>
          <div className="absolute bottom-2 left-2 bg-white bg-opacity-90 px-2 py-1 rounded-full text-xs text-gray-600 flex items-center">
            <MapPin size={12} className="mr-1" />
            {formatDistance(distance)}
          </div>
        </div>
      )}

      <div className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-semibold mb-1">{pin.title}</h3>
          <div className="flex space-x-1">
            <button
              onClick={() => onEdit(pin)}
              className="text-gray-500 hover:text-amber-500 p-1 rounded-full hover:bg-gray-100 transition-colors"
              title="Edit pin"
            >
              <Edit size={16} />
            </button>
            {isAdmin && (
              <button
                onClick={() => onDelete(pin.id)}
                className="text-gray-500 hover:text-red-500 p-1 rounded-full hover:bg-gray-100 transition-colors"
                title="Delete pin"
              >
                <Trash2 size={16} />
              </button>
            )}
          </div>
        </div>

        <p className="text-xs text-gray-500 mb-2">
          {format(new Date(pin.createdAt), 'MMMM d, yyyy')}
        </p>
        
        <p className="text-sm text-gray-700 mb-3 line-clamp-2">{pin.description}</p>
        
        <div className="flex flex-wrap gap-1">
          {pin.hashtags.map((tag) => (
            <button
              key={tag}
              onClick={() => addHashtagFilter(tag)}
              className="px-2 py-0.5 bg-primary-50 text-primary-700 rounded-full text-xs hover:bg-primary-100 transition-colors"
            >
              #{tag}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PinCard;