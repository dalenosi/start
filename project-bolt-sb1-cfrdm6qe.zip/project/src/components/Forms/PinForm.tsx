import React, { useState, useEffect } from 'react';
import { Pin } from '../../types';
import { X, MapPin, Link2, Image as ImageIcon } from 'lucide-react';
import { usePins } from '../../contexts/PinContext';

interface PinFormProps {
  initialPin?: Pin;
  onSubmit: (pin: Omit<Pin, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
  selectedLocation?: { lat: number; lng: number };
}

const PinForm: React.FC<PinFormProps> = ({
  initialPin,
  onSubmit,
  onCancel,
  selectedLocation,
}) => {
  const { addPin, updatePin } = usePins();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [hashtagInput, setHashtagInput] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  useEffect(() => {
    if (initialPin) {
      setTitle(initialPin.title);
      setHashtags(initialPin.hashtags);
      setDescription(initialPin.description);
      setImageUrl(initialPin.imageUrl);
      setImagePreview(initialPin.imageUrl);
      setWebsiteUrl(initialPin.websiteUrl || '');
      setLatitude(initialPin.latitude);
      setLongitude(initialPin.longitude);
      setStartDate(initialPin.startDate || '');
      setEndDate(initialPin.endDate || '');
    }
  }, [initialPin]);

  useEffect(() => {
    if (selectedLocation) {
      setLatitude(selectedLocation.lat);
      setLongitude(selectedLocation.lng);
    }
  }, [selectedLocation]);

  const handleHashtagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const tag = hashtagInput.trim().replace(/^#/, '');
      if (tag && !hashtags.includes(tag)) {
        setHashtags([...hashtags, tag]);
        setHashtagInput('');
      }
    }
  };

  const removeHashtag = (tagToRemove: string) => {
    setHashtags(hashtags.filter(tag => tag !== tagToRemove));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setErrors(prev => ({ ...prev, image: 'Image size must be less than 5MB' }));
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setImageUrl(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (latitude === null || longitude === null) {
      newErrors.location = 'Please select a location on the map';
    }
    
    if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
      newErrors.dateRange = 'End date must be after start date';
    }

    if (websiteUrl && !isValidUrl(websiteUrl)) {
      newErrors.websiteUrl = 'Please enter a valid URL';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidUrl = (url: string) => {
    try {
      new URL(url);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    const pinData = {
      title,
      hashtags,
      description,
      imageUrl: imageUrl || 'https://images.pexels.com/photos/1796730/pexels-photo-1796730.jpeg',
      websiteUrl: websiteUrl || undefined,
      latitude: latitude!,
      longitude: longitude!,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
    };

    if (initialPin) {
      updatePin({ ...pinData, id: initialPin.id, createdAt: initialPin.createdAt });
    } else {
      addPin(pinData);
    }
    
    onSubmit(pinData);
  };

  return (
    <div className="bg-white rounded-lg shadow-md animate-slide-up">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-lg font-semibold">{initialPin ? 'Edit Pin' : 'Add New Pin'}</h2>
        <button
          onClick={onCancel}
          className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
        >
          <X size={20} />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="p-4 space-y-4">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
            Title <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className={`w-full px-3 py-2 border ${
              errors.title ? 'border-red-500' : 'border-gray-300'
            } rounded-lg focus:ring-primary-500 focus:border-primary-500`}
          />
          {errors.title && <p className="mt-1 text-xs text-red-500">{errors.title}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Location <span className="text-red-500">*</span>
          </label>
          {latitude !== null && longitude !== null ? (
            <div className="flex items-center space-x-2">
              <div className="px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-sm flex-1 flex items-center">
                <MapPin size={16} className="text-primary-600 mr-2" />
                <span>
                  {latitude.toFixed(4)}, {longitude.toFixed(4)}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setLatitude(null);
                  setLongitude(null);
                }}
                className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
              >
                <X size={16} />
              </button>
            </div>
          ) : (
            <div className={`px-3 py-2 border ${
              errors.location ? 'border-red-500' : 'border-gray-300'
            } rounded-lg text-gray-500 text-sm flex items-center`}>
              <MapPin size={16} className="mr-2" />
              <span>Click on the map to set the pin location</span>
            </div>
          )}
          {errors.location && <p className="mt-1 text-xs text-red-500">{errors.location}</p>}
        </div>

        <div>
          <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-1">
            Image <span className="text-gray-500 text-xs font-normal">(optional)</span>
          </label>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <label className="flex-1">
                <div className="relative">
                  <input
                    type="file"
                    id="image"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                  />
                  <div className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 cursor-pointer hover:bg-gray-50 flex items-center">
                    <ImageIcon size={16} className="text-gray-400 mr-2" />
                    <span>Choose an image</span>
                  </div>
                </div>
              </label>
              {imagePreview && (
                <button
                  type="button"
                  onClick={() => {
                    setImagePreview(null);
                    setImageUrl('');
                  }}
                  className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                >
                  <X size={16} />
                </button>
              )}
            </div>
            {errors.image && <p className="text-xs text-red-500">{errors.image}</p>}
            {imagePreview && (
              <div className="relative w-full h-40 rounded-lg overflow-hidden">
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="websiteUrl" className="block text-sm font-medium text-gray-700 mb-1">
            Website URL <span className="text-gray-500 text-xs font-normal">(optional)</span>
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Link2 size={16} className="text-gray-400" />
            </div>
            <input
              type="text"
              id="websiteUrl"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              placeholder="https://example.com"
              className={`w-full pl-10 pr-3 py-2 border ${
                errors.websiteUrl ? 'border-red-500' : 'border-gray-300'
              } rounded-lg focus:ring-primary-500 focus:border-primary-500`}
            />
          </div>
          {errors.websiteUrl && <p className="mt-1 text-xs text-red-500">{errors.websiteUrl}</p>}
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
            Description <span className="text-gray-500 text-xs font-normal">(optional)</span>
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
          />
        </div>

        <div>
          <label htmlFor="hashtags" className="block text-sm font-medium text-gray-700 mb-1">
            Hashtags <span className="text-gray-500 text-xs font-normal">(optional, press Enter to add)</span>
          </label>
          <input
            type="text"
            id="hashtags"
            value={hashtagInput}
            onChange={(e) => setHashtagInput(e.target.value)}
            onKeyDown={handleHashtagKeyDown}
            placeholder="Type and press Enter"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
          />
          <div className="mt-2 flex flex-wrap gap-2">
            {hashtags.map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center px-2 py-1 rounded-full text-sm bg-primary-100 text-primary-800"
              >
                #{tag}
                <button
                  type="button"
                  onClick={() => removeHashtag(tag)}
                  className="ml-1 rounded-full hover:bg-primary-200 p-0.5"
                >
                  <X size={14} />
                </button>
              </span>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date Range <span className="text-gray-500 text-xs font-normal">(optional)</span>
          </label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              />
              <p className="mt-1 text-xs text-gray-500">Start date</p>
            </div>
            <div>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              />
              <p className="mt-1 text-xs text-gray-500">End date</p>
            </div>
          </div>
          {errors.dateRange && <p className="mt-1 text-xs text-red-500">{errors.dateRange}</p>}
        </div>
        
        <div className="flex justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-sm text-gray-700 hover:text-gray-900 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors"
          >
            {initialPin ? 'Save Changes' : 'Add Pin'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PinForm;