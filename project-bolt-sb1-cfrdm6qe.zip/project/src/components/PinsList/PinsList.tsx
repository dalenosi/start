import React, { useState } from 'react';
import { usePins } from '../../contexts/PinContext';
import PinCard from './PinCard';
import { Pin } from '../../types';
import { Search, X } from 'lucide-react';

interface PinsListProps {
  onNavigateToPin: (lat: number, lng: number) => void;
  onEditPin: (pin: Pin) => void;
  sortedPins: Array<{ pin: Pin; distance: number }>;
}

const PinsList: React.FC<PinsListProps> = ({ onNavigateToPin, onEditPin, sortedPins }) => {
  const { deletePin } = usePins();
  const [searchTerm, setSearchTerm] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const displayedPins = searchTerm
    ? sortedPins.filter(
        ({ pin }) =>
          pin.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          pin.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          pin.hashtags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    : sortedPins;

  return (
    <div className="bg-white">
      <div className="sticky top-0 px-4 py-3 bg-white/80 backdrop-blur-sm z-10">
        <div className="relative">
          <div className={`relative transition-all duration-200 ${isFocused ? 'scale-[1.02]' : 'scale-100'}`}>
            <input
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder="Search pins..."
              className={`w-full pl-11 pr-10 py-3 bg-gray-50 border-2 rounded-xl 
                focus:ring-2 focus:ring-primary-500 focus:border-transparent
                focus:bg-white transition-all duration-200 outline-none
                placeholder:text-gray-400 text-gray-700
                ${isFocused ? 'border-primary-300 shadow-lg' : 'border-gray-200 shadow-sm'}`}
            />
            <Search 
              size={20} 
              className={`absolute left-3.5 top-1/2 transform -translate-y-1/2 transition-colors duration-200
                ${isFocused ? 'text-primary-500' : 'text-gray-400'}`}
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 rounded-full
                  hover:bg-gray-100 active:bg-gray-200 transition-colors duration-200"
              >
                <X size={18} className="text-gray-400 hover:text-gray-600" />
              </button>
            )}
          </div>
          {searchTerm && (
            <div className="absolute left-4 -bottom-6 text-sm text-gray-500">
              Found {displayedPins.length} result{displayedPins.length !== 1 ? 's' : ''}
            </div>
          )}
        </div>
      </div>
      
      <div className={`px-4 pb-4 ${searchTerm ? 'pt-8' : 'pt-2'}`}>
        {displayedPins.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {displayedPins.map(({ pin, distance }) => (
              <PinCard
                key={pin.id}
                pin={pin}
                distance={distance}
                onEdit={onEditPin}
                onDelete={deletePin}
                onNavigateToPin={onNavigateToPin}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            <Search size={48} className="text-gray-300 mb-4" />
            <p className="text-lg font-medium mb-1">No results found</p>
            <p className="text-sm text-gray-400">
              {searchTerm ? 'Try different keywords or filters' : 'No pins available'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PinsList